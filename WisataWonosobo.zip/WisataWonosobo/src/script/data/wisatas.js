const wisatas = [
    {
      name: 'Kebun Teh Wonosobo',
      location: 'Desa Pagerkukuh, Kecamatan Garung, Kabupaten Wonosobo',
      description: 'Kebun Teh Wonosobo merupakan salah satu destinasi wisata yang terkenal di Wonosobo. Wisatawan dapat menikmati keindahan kebun teh yang luas dan menikmati secangkir teh dari hasil panen langsung di kebun teh. Selain menikmati teh, wisatawan juga dapat belajar mengenai proses pembuatan teh dari daun teh yang dipetik di kebun teh tersebut.',
      theme: 'Wisata Alam'
    },
    {
      name: 'Curug Cipendok',
      location: 'Desa Cipendok, Kecamatan Watumalang, Kabupaten Wonosobo',
      description: 'Curug Cipendok merupakan salah satu air terjun yang terletak di kawasan pegunungan Menoreh. Air terjun ini memiliki ketinggian sekitar 30 meter dan terdapat kolam air yang dapat digunakan untuk berenang. Selain menikmati keindahan alam, wisatawan juga dapat melakukan kegiatan hiking dan camping di sekitar kawasan air terjun.',
      theme: 'Wisata Alam'
    },
    {
      name: 'Gunung Sumbing',
      location: 'Desa Garung, Kecamatan Garung, Kabupaten Wonosobo',
      description: 'Gunung Sumbing merupakan salah satu gunung yang terkenal di Jawa Tengah. Wisatawan dapat melakukan pendakian ke puncak gunung yang memiliki ketinggian sekitar 3.371 meter di atas permukaan laut. Selain pendakian, wisatawan juga dapat menikmati keindahan alam di sekitar gunung Sumbing dan berkemah di kawasan gunung tersebut.',
      theme: 'Wisata Alam'
    },
    {
      name: 'Bukit Sikunir',
      location: 'Desa Sumbing, Kecamatan Garung, Kabupaten Wonosobo',
      description: 'Bukit Sikunir merupakan salah satu spot terbaik untuk menikmati keindahan sunrise di Wonosobo. Bukit ini memiliki ketinggian sekitar 2.200 meter di atas permukaan laut dan memiliki pemandangan alam yang indah. Wisatawan dapat melakukan pendakian ringan untuk mencapai puncak bukit dan menikmati keindahan alam di sekitarnya.',
      theme: 'Wisata Alam'
    },
    {
      name: 'Museum Wayang',
      location: 'Jl. Cempaka No. 9, Kecamatan Wonosobo, Kota Wonosobo',
      description: 'Museum Wayang Wonosobo merupakan museum yang mengoleksi berbagai jenis wayang dari seluruh Indonesia. Selain wayang, museum ini juga memiliki koleksi alat musik tradisional dan peralatan pertunjukan wayang. Wisatawan dapat belajar mengenai sejarah dan kebudayaan Indonesia melalui koleksi yang ada di museum ini.',
      theme: 'Wisata Budaya'
      },
];

export default wisatas;
