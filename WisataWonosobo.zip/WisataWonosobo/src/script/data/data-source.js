import './wisatas.js'

class DataSource {
  static searchWisata(keyword) {
    return fetch(`https://www.thesportsdb.com/api.php`)
        .then(response => {
          return response.json();
        })
        .then(responseJson => {
          if (responseJson.data) {
            return Promise.resolve(responseJson.data);
          } else {
            return Promise.reject(`${keyword} is not found`);
          }
        });
  }
}

export default DataSource;