
class WisataItem extends HTMLElement {

  constructor() {
    super();
    this.shadowDOM = this.attachShadow({mode: 'open'});
  }

  set wisata(wisata) {
    this._wisata = wisata;
    this.render();
  }

  render() {
    this.shadowDOM.innerHTML = `
    <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    :host {
      display: block;
      margin-bottom: 18px;
      box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
      border-radius: 10px;
      overflow: hidden;
    }
    .wisata-image {
      width: 100%;
      max-height: 300px;
      object-fit: cover;
      object-position: center;
    }
    .wisata-info {
      padding: 24px;
      background-color: #f9f7f7;
    }
    .wisata-info > h2 {
      font-weight: lighter;
      color: #4d4d4d;
      margin-bottom: 12px;
    }
    .wisata-info > p {
      font-size: 16px;
      margin-top: 10px;
      color: #4d4d4d;
      line-height: 1.5;
      overflow: hidden;
      text-overflow: ellipsis;
      display: -webkit-box;
      -webkit-box-orient: vertical;
      -webkit-line-clamp: 10; /* number of lines to show */
    }
  </style>
      
      <div class="wisata-info">
        <h2>${this._wisata.strTeam}</h2>
        <p>${this._wisata.strDescriptionEN}</p>
      </div>
    `;
  }
}

customElements.define('wisata-item', WisataItem);
