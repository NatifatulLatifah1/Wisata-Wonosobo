import './wisata-item.js';

class WisataList extends HTMLElement {

  constructor() {
    super();
    this.shadowDOM = this.attachShadow({mode: 'open'});
  }

  set wisatas(wisatas) {
    this._wisatas = wisatas;
    this.render();
  }

  render() {
    this.shadowDOM.innerHTML = '';

    this.wisatas.forEach(wisata => {
      const wisataItemElement = document.createElement('wisata-item');
      wisataItemElement.wisata = wisata;
      this.shadowDOM.appendChild(wisataItemElement);
    });
  }

  renderError(message) {
    this.shadowDOM.innerHTML = `
    <style>
    .placeholder {
      font-weight: lighter;
      color: #4d4d4d;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
    }
  </style>
    `;

    this.shadowDOM.innerHTML += `<h2 class="placeholder">${message}</h2>`;
  }
}

customElements.define('wisata-list', WisataList);
